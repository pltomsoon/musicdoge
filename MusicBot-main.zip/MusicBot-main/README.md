# Discord.js v13 Music Bot
This project was created for you to create your own music bot, adapted to run on a virtual computer or on your own computer, **Github.com** is a privately published discord music bot project.<br><br>
<h1>Music Bot Installation Guide</h1><hr>
<h1><a href="https://youtu.be/6WQIiojePQ8">VİDEO GUIDE</a></h1>
<b>1 |</b> Download the project from <b>github.com</b> to your computer, transfer it from the zip file to a regular file and write your discord bot token in the section that says <b>TOKEN</b> in the <b>config.js</b> file.<br><br>
<b>2 |</b> Download and install the latest version of Node.js on your computer, run as administrator after installation.<br><br>
<b>3 |</b> Download the coding editor named Visual studio code.<br><br>
<b>4 |</b> Open the folder where you transferred the music bot project with visual studio code.<br><br>
<b>5 |</b> select terminal -> new terminal from the top left menu.<br><br>
<b>6 |</b> The part that opens is your console. Everything is visible here, first of all, type <b>npm install</b> here and wait for the modules required for the music bot to be installed.<br><br>
<b>7 |</b> Run the file named <b>start.bat</b> in the folder where the music bot codes are located. your music bot will be active.<br><br>
<b>8 |</b> As long as you don't close the window we opened with start.bat, your discord bot will remain active, after all you can close the visual studio code editor.<br><hr><br>
<h2>Good Luck to You with the Music Bot.</h2>
<br>
Umut Bayraktar Youtube: <a href="https://www.youtube.com/UmutBayraktarYT">Subscribe</a><br>
Code Share Discord: <a href="https://discord.gg/6XGqdgE">Join</a><br>
